# Example project

Some **notes** about it.
